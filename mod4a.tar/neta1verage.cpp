#include <iostream>
#include <fstream>
#include <string>
using namespace std;
//variables defs from main  
extern int counter;//counter for loops AND number or employees entered
extern double net[100];//net for computation and display

// function, compute net average and display
void myAverage(void){
	int i = 0;
	ofstream myfile; //MYFILE, declare object for input
	myfile.open("p1ayroll.txt");// open and make input file	
	while (i!=counter){
		cout << "THE VALUE OF net[" << i <<"] is " << net[i];//output something for a test
		cout << endl;
		myfile << net[i]; //feed myfile
		myfile << endl;
		i++;//increment
	}//END WHILE
	myfile << endl;
	myfile << "hehe!";
	myfile.close();//MYFILEremains open for all values
	//part2
	ifstream meme;
	meme.open("p1ayroll.txt");
	double value[counter-1]; //zero index the value		
	double sum = 0, avg =0; //double scoop the variables 
	i=0;//reset i
	cout << endl;
	while (i!=counter)
		 {
			meme >> value[i];//feed the variable, populate the array
			cout << "VALUE says... " << value[i] << "   ,BINGO!" << endl;//value[0]+value[1], next step			
			sum = sum + value[i];
			i++;
		 }//END IF
	cout << "NET SUM is... " << sum;
	avg = sum / counter;
	cout << endl << "NET AVERAGE IS.. " << avg;	 
	//meme.close();	 //close after '}' implicit	   
}//MYAVERAGE        
//END OF FUNCTION
