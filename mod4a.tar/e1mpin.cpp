#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
//external variables
extern int counter;//counter for loops
extern string fname[15];
extern string lname[17];
extern int id[100];
extern double hw[100], hr[100];
extern int oth[100], otp[100];
extern double gp[100], tax[100], reg[100], net[100];
//function definition    
void myData(){
    int n = 0;
		cout << "Please enter number of Employees:";
		cin >> counter;
	while (n!=counter){ //input loop --read all data into arrays
		cout <<endl; 
		cout<<"ENTER EMPLOYEE ID# ";
		cin>>id[n];
		cout << "ENTER FIRST NAME: ";
		cin >> fname[n];
		cout << "ENTER LAST NAME: "; 
		cin >> lname[n];
		cout << "ENTER HOURS WORKED: ";
		cin >> hw[n];
		cout << "ENTER HOURLY RATE: ";
		cin >> hr[n];
		n++; //increment
    } //WHILE
}//MYDATA
