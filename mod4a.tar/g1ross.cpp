#include <iostream>
#include <iomanip>
//using namespace std;

//external variables    
extern int counter, otp[100];//counter for loops, opt for pays
//extern int i;//instance for data
extern double gp[100], reg[100];//var.s for function


//function def.s
void myGross(void){

        for ( int i = 0; i<counter; i++){//loop to ++compute gross pays
                gp[i] = reg[i] + otp[i];
        }//FOR
}//MYGROSS
