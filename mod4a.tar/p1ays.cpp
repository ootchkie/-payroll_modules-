#include <iostream>
#include <iomanip>
//#include "var.cpp"
using namespace std;
//external variables
extern int counter;//counter for loops
extern char fname[100][15];
extern char lname[100][17];
extern int id[100];
extern double hw[100], hr[100];
extern int oth[100], otp[100];
 extern double gp[100], tax[100], reg[100], net[100];
//    extern int i;//instance for data

void myPays(void){
        
        for ( int i = 0; i<counter; i++){//hours and pays loop ++compute pays
                        //logic for overtime hours
                        if (hw[i] > 40){
                                oth[i] = hw[i] - 40;
                                otp[i] = oth[i]*(hr[i]* 1.5);//++time and a half overtime pay
                                reg[i] = hr[i]*40;//compute reg pay
                        }//IF
                        //compute regpay
                        else oth[i] = 0, otp[i]=0, reg[i]= hw[i]*hr[i];
        }//FOR  
}//MYPAYS

