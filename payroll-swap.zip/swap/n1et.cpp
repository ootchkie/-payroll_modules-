#include <iostream>
#include <iomanip>
//using namespace std;

//variables from main    
extern int counter;//counter for loops
extern double gp[100], tax[100], net[100];//for function
//int i;//instance for data

void myNet(void){
        
        for ( int i = 0; i<counter; i++){ //final calculation loop ++compute net pay
                net[i]=(gp[i]-(gp[i]*tax[i]));
    }//FOR
}//MYNET
