#include <iostream>
#include <iomanip>
//using namespace std;

//variables defs    
extern int counter;//counter for loops
extern double gp[100], tax[100];//from main

//extern int i;//instance for data
void myTax(void){

        for ( int i = 0; i<counter; i++){//seperate loop for ++compute taxes
                if (gp[i]>1000){//logic for taxrates
                                tax[i]=.03;
                        }
                
                        else if (gp[i]>800){
                                tax[i]=.02;
                        }               
                        else if (gp[i]>500){  
                                tax[i]=.01;
                        }
                        else tax[i]=.00;                   
        }//FOR
}//MYTAX        

