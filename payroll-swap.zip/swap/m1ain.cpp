#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
//function prototypes
void myData(); 
void myPays();
void myGross();
void myTax();
void myNet();
void myTable();
void myAverage();
void mySwap();
//variables defs    
int counter;//counter for loops
string fname[15];
string lname[17];
int id[100];
double hw[100], hr[100];
int oth[100], otp[100];
double gp[100], tax[100], reg[100], net[100];    
double value[100]; //zero index the value
//new main for all sections now contained in seperate functions(as requested) in seperate files to be compiled at once together into single program
int main(){
	//function calls for inputs and pay logics
     myData();
    myPays();
     myGross();
	myTax();
     myNet();

        //company output data and table ++header
        cout << " " << endl;
        cout << "...DR. EBRAHIMI'S PAYROLL INSTITUTE..." << endl;
        cout << " " << endl;cout<<endl<<setw(2)<<"ID"<<setw(8)<<"NAME"<<setw(19)<<"HOURS"<<setw(6)<<"RATE"<<setw(5)<<"OTH"<<setw(6)<<"OTP"<<setw(6)<<"RGP"<<setw(6)<<"GRP"<<setw(6)<<"TAX"<<setw(8)<<"NET"<<endl<<endl;
        
        //function calls for table data and net pay average
     myTable();
        cout << " " << endl;
      myAverage();
      mySwap();  
	return 0;
}//MAIN
