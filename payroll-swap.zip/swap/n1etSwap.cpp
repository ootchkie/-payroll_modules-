#include <iostream>
#include <fstream>
#include <string>
using namespace std;
// variables defs from main
extern double value[100]; //net(i) for computational purposes
extern int counter;//counter for loops 
// function, swap values of netpay(0) and netpay(1) and order them according to size
void mySwap(){
	
	for ( int i = 0; i<counter; i++){//external loop
		
		double x=value[counter];
		double y=(x + 1);       //internal local variables
		
		cout << "X AND Y BEFORE THE SWAP " <<"x is " << x <<"y is " << y;
		cout << '\n';
				
		
			if (x < y){//internal if
               		
				int swap = x;//swap variable
				x = y;
				y = swap;
			cout << "X AND Y AFTER THE SWAP " <<"x is " << x <<"y is " << y; 
		counter = counter-1;
		}//IF	
	}//FOR

return;

}
