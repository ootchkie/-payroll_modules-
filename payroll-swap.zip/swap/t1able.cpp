#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
// variables from main    
extern int counter;//counter for loops
extern string fname[15];
extern string lname[17];
extern int id[100];
extern double hw[100], hr[100];
extern int oth[100], otp[100];
extern double gp[100], tax[100], reg[100], net[100];


               
// function mytable definition
void myTable(void){
    for ( int i = 0; i<counter; i++){ //tabular loop for ++output data arrays
               
                cout<<setw(4) << left <<id[i] <<"  " ;//left helps with numeber spacing
                int wid = 22;// total column width of name
                
                // differenc + length = total width ||  d=w-l  
                int dif =((wid)-((fname[i].length())+(lname[i].length())));//makes columns print evenly
                
                cout<<  right  <<fname[i]<<" "<<lname[i];//right helps with namespace 
                cout<<setw(dif)<<hw[i];
                cout<<setw(5)  << hr[i];
                cout<<setw(6)  << oth[i];
                cout<<setw(6)  << otp[i];
                cout<<setw(6)  << reg[i];
                cout<<setw(6)  << gp[i];
                cout<<setw(6)  << tax[i];
                cout<<setw(8)  <<net[i] ;
                cout << endl << endl;           
        }//FOR
}//MYTABLE
